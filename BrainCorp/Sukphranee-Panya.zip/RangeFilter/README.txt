Files
/RangeFilter/RangeFilter.h    -header file for range filter
/RangeFilter/RangeFilter.cpp  -source file for range filter
/RangeFilter/main.cpp         -demonstration program to test range filter

Usage
the RangeFilter object need two arguments for its constructor, the lower bound
and upper bound to filter the vectors value. The filter is applied to an arbitrary size vector.
