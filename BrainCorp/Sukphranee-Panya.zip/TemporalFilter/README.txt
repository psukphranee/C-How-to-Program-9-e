Files:

/TemporalFilter/main.cpp - Demonstration program for the temporal filter
/TemporalFilter/TemporalFilter.h - header for temporal filter
/TemporalFilter/TemporalFilter.cpp - source file for temporal filter

Usage:
The temporal filter object, TemporalFilter, needs one parameter for the constructor.
That parameter specifies the number of previous scans, D. More notes are in the comments.
